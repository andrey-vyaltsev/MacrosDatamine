1. Скопируйте файл "Datamine.sublime-syntax" в папку:

C:\Users\Ваше имя пользователя\AppData\Roaming\Sublime Text\Packages

2. Откройте Sublime Text и выберете в правом нижнем углу синтаксис "Datamine"

3. Наслаждайтесь написанием и чтением макросов